package com.prestashop.test;

import org.testng.annotations.Test;

public class JDBCTest {
  @Test
  public void f() {
  }
}
